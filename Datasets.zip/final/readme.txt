The data format follows,

u_1 \t u_2 \t u_3 \t ... \t u_m \t r \n

...

Every utterance u_i has been tokenized and tokens are separated by ' '.